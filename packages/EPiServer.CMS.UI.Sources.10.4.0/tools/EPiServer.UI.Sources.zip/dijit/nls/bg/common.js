define(
({
	buttonOk: "ОК",
	buttonCancel: "Отмени",
	buttonSave: "Запази",
	itemClose: "Затвори"
})
);
