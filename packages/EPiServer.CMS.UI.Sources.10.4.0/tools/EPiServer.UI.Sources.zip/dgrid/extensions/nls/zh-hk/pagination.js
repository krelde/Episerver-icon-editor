define({
    status: "${start} - ${end} 共 ${total} 條結果",
		gotoFirst: "首頁",
		gotoNext: "上一頁",
		gotoPrev: "下一頁",
		gotoLast: "末頁",
		gotoPage: "到這頁",
		jumpPage: "跳到頁"
});
